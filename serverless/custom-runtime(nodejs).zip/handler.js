/**
 * Describe the basic method of Cloud Functions
 */

const express = require('express');
const log4js = require("log4js");
const app = express();

let logConfig = {
    replaceConsole: true,
    appenders: {
        'out': {
            type: 'stdout',
            layout: {
                type: "colored"
            }
        },
        'files': {
            type: 'file',
            filename: '/opt/huawei/logs/logs.log'
        }
    },
    categories: {
        default: {
            appenders: ['out', 'files'],
            level: "INFO"
        }
    },
    disableClustering: true
}
log4js.configure(logConfig);
const logger = log4js.getLogger('CUSTOM-RUNTIME-NODEJS-DEMO-LOG');

app.post('/invoke', function (req, res) {
    // example of display environment variables
    let env1 = process.env.env1;

    // example of display logs
    logger.info("Test info log");
    logger.warn("Test warn log");
    logger.debug("Test debug log");
    logger.error("Test error log");

    logger.info("--------Start-------");
    try {
        let startTime = new Date().getTime();
        let endTime = startTime;
        let interval = 0;
        startTime = process.uptime() * 1000;

        // print input parameters and environment variables
        logger.info("req: " + req.query);
        logger.info("env1: " + env1);

        endTime = process.uptime() * 1000;
        interval = endTime - startTime;
        logger.info("intervalTime: " + interval);
        logger.info("--------Finished-------");

        let result = {"intervalTime": interval};
        res.send(JSON.stringify(result));
    } catch (error) {
        logger.error("--------Error-------");
        logger.error("error: " + error);
        res.send(error);
    }
});

app.listen(9000, function () {
    logger.info("---------server start now!-------");
});